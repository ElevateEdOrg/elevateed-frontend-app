import React, { Component } from 'react';
import Carousel from 'react-native-snap-carousel';
import { View, Text, Image, Dimensions, StyleSheet, Platform, ViewStyle } from 'react-native';
import { image } from '../constants/images';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
  } from 'react-native-responsive-screen';

const { width: screenWidth } = Dimensions.get('window');

interface Entry {

  thumbnail: any; 
}


const ENTRIES1: Entry[] = [
  {

    thumbnail: image.CAROUSEL1,
  },
  {

    thumbnail: image.CAROUSEL1,
  },
  {
  
    thumbnail:image.CAROUSEL1,
  },
  {

    thumbnail: image.CAROUSEL1,
  },
  {

    thumbnail:image.CAROUSEL1,
  },
];

interface MyCarouselProps {
    style?: ViewStyle; 
  }
  
  interface MyCarouselState {
    entries: Entry[];
    activeSlide: number;
  }

export default class MyCarousel extends Component<MyCarouselProps, MyCarouselState> {
  private carouselRef = React.createRef<Carousel<Entry>>();

  constructor(props: {}) {
    super(props);
    this.state = {
      entries: ENTRIES1,
      activeSlide: 0,
    };
  }

  componentDidMount() {
    this.autoPlay();
  }

  autoPlay = () => {
    setInterval(() => {
      if (this.carouselRef.current) {
        let nextIndex = (this.state.activeSlide + 1) % this.state.entries.length;
        this.setState({ activeSlide: nextIndex });
        this.carouselRef.current.snapToItem(nextIndex);
      }
    }, 5000);
  };

  _renderItem = ({ item }: { item: Entry }) => {
    return (
      <View style={styles.item}>
        <Image source={item.thumbnail} style={styles.image} />
       
      </View>
    );
  };

  render() {
    const { style } = this.props;
    return (
      <Carousel
        ref={this.carouselRef}
        sliderWidth={screenWidth}
        sliderHeight={screenWidth}
        itemWidth={300} // Adjusted to match image size
        data={this.state.entries}
        renderItem={this._renderItem}
        loop={true}
        autoplay={true}
        autoplayInterval={5000}
      />
    );
  }
}

const styles = StyleSheet.create({
  item: {
    marginTop:hp('3%'),

  },
  image: {
    width: 300,
    height: 200,
    borderRadius: 8,
    resizeMode: 'cover',
  },
  
});
