export const TextStyles = {
    extraBoldText: 'Poppins-ExtraBold',
    boldText: 'Poppins-Bold',
    semiBoldText: 'Poppins-SemiBold',
    regularText: 'Poppins-Regular',
    mediumText: 'Poppins-Medium',
    veryextraBoldText: 'Poppins-Black',
  };
  