export const Colors = {
primary: '#3D5CFF',
secondary: '#FFFFFF',
background: '#1F1F39'
}