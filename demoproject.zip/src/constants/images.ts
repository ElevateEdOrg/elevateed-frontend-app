export const image={
    LOGO: require('../assets/image/logo.png'),
    ONBOARDING1:require('../assets/image/OB1.png'),
    ONBOARDING2:require('../assets/image/OB2.png'),
    ONBOARDING3:require('../assets/image/OB3.png'),
    PROFILEPERSON:require('../assets/image/person.png'),
    CAROUSEL1:require('../assets/image/C1.png'),
}

export const icons={
    IC_EYE_OPEN: require('../assets/icons/eye_open1.png'),
    IC_EYE_CLOSE: require ('../assets/icons/eye_close1.png')
}