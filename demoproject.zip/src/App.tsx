import React from 'react';
import AppNavigator from './navigation/AppNavigator';



function App(): React.JSX.Element {
  console.log('hel')
  return <AppNavigator />
}
export default App;
